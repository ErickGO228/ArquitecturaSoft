<?php
$servername = "localhost:3308"; // Especifica el puerto 3308 para la conexión
$username = "root"; // Cambia esto si tu nombre de usuario es diferente
$password = "root"; // Cambia esto si tu contraseña es diferente
$dbname = "crud"; // Nombre de tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Revisar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
} else {
    echo "Conexión exitosa"; // Esto se mostrará si la conexión se realiza con éxito
}
?>
