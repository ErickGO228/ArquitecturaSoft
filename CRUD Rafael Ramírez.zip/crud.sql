CREATE DATABASE crud;

USE crud;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL
);

INSERT INTO users(name, email)
VALUES
    ("Rafael", "rafael@mail.com");
