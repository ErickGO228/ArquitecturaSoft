<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple CRUD System</title>
</head>
<body>
    <h2>Usuarios</h2>
    <a href="create.php">Agregar Usuario</a>
    <br><br>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Acciones</th>
        </tr>
        <?php
            // Ya has incluido 'config.php' al principio del archivo

            $sql = "SELECT * FROM users";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>".$row["id"]."</td>
                            <td>".$row["name"]."</td>
                            <td>".$row["email"]."</td>
                            <td>
                                <a href='edit.php?id=".$row["id"]."'>Editar</a> |
                                <a href='delete.php?id=".$row["id"]."'>Eliminar</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No hay usuarios</td></tr>";
            }
            $conn->close();
        ?>
    </table>
</body>
</html>
