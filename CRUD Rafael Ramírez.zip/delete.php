<?php
include 'config.php';

// Verifica si se ha enviado el ID del usuario a eliminar
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Elimina el registro de la base de datos
    $sql = "DELETE FROM users WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "Registro eliminado exitosamente";
    } else {
        echo "Error al eliminar el registro: " . $conn->error;
    }
} else {
    echo "No se proporcionó el ID del usuario a eliminar";
}
?>
